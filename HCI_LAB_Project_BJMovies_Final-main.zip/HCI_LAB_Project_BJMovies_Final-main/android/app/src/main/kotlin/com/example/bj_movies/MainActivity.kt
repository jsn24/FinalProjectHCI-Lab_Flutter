package com.example.bj_movies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
